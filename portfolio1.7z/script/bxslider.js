$(".carusel").bxSlider({
    mode: "fade",
    controls: false,
    randomStart: true,
    pager:true,
})

